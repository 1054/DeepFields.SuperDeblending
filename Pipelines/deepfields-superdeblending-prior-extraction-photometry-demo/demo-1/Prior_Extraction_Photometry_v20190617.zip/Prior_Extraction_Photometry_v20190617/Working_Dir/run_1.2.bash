#!/bin/bash
# 
source /Users/dzliu/Cloud/Github/DeepFields.SuperDeblending/SETUP.bash
cd $(dirname "${BASH_SOURCE[0]}")

# photometry
astrodepth_prior_extraction_photometry \
    -cat "../Input_Catalog/irac_mips_fluxes_cdfs_id_ra_dec.txt" \
    -sci "../Input_Sci_Images/1/cut_2_rect_38_-10_105_57/s_mips_1_s1_v0.30_sci.cut_38_-10_105_57.fits" \
    -psf "../Input_Psf_Images/1/hdfn_dao_mipspsf.fits" \
    -rms "../Input_Rms_Images/1/cut_2_rect_38_-10_105_57/s_mips_1_s1_v0_30_rms_ED.cut_38_-10_105_57.fits" \
    -buffer 10 \
    -output-dir "1" \
    -output-name "cut_2_rect_38_-10_105_57" \
    -steps getpix galfit gaussian sersic  final \
    

# cleaning
if [[ -d "1/cut_2_rect_38_-10_105_57/" ]]; then
   cd "1/cut_2_rect_38_-10_105_57/"
   rm galfit.* aaa_* aaa.* *.sky2xy.* *.tmp *.backup 2>/dev/null
fi


