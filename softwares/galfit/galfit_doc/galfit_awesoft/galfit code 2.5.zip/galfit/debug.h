#define DEBUG 0
#define CKIMG 0
