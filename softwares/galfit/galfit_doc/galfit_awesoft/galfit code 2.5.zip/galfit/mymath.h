#define NINT(f) (((f) > 0.) ? (int) ((f) + 0.5) : (int)((f) - 0.5))
