#!/bin/bash
#
set -e  # set this to quit immediately when got any small error
source /dsm/upgal/data/dliu/Superdeblending/Softwares/SETUP  # this will automatically load IRAF if hostname is planer*
cd /dsm/upgal/data/dliu/Superdeblending/Softwares/iraf_on_planer/
cl < tmp.cl


